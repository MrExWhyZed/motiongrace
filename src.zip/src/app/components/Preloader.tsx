'use client';

import { useEffect, useRef, useState } from 'react';

export const PRELOADER_DONE_EVENT  = 'motionGracePreloaderDone';
export const HERO_READY_EVENT      = 'motionGraceHeroReady';
export const HERO_VIDEO_READY_EVENT = 'motionGraceHeroVideoReady';

export default function Preloader() {
  const rootRef     = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef      = useRef<SVGTextElement>(null);
  const secondaryTextRef = useRef<SVGTextElement>(null);

  const [skip, setSkip] = useState<boolean>(false);

  useEffect(() => {
    try {
      const storedOrigin  = sessionStorage.getItem('mg_origin');
      const currentOrigin = String(Math.round(performance.timeOrigin));

      if (storedOrigin !== currentOrigin) {
        sessionStorage.setItem('mg_origin', currentOrigin);
        sessionStorage.removeItem('mg_preloader_done');
      } else {
        setSkip(true);
        return;
      }
    } catch { /* show preloader */ }
  }, []);

  useEffect(() => {
    if (skip) {
      window.dispatchEvent(new CustomEvent(PRELOADER_DONE_EVENT));
      return;
    }

    let mounted = true;
    let cleanup = () => {};

    void (async () => {
      const [{ gsap }] = await Promise.all([
        import('gsap'),
      ]);

      if (!mounted || !containerRef.current || !textRef.current || !secondaryTextRef.current) return;

      const ctx = gsap.context(() => {
        // ── Initial states ────────────────────────────────────────────
        gsap.set(containerRef.current, { autoAlpha: 1 });
        gsap.set(textRef.current, { opacity: 0 });
        gsap.set(secondaryTextRef.current, { opacity: 0 });

      const tl = gsap.timeline();

      // ── Flickering Entry Animation ────────────────────────────────
      // We simulate a 'failing light' or 'cinematic boot' flicker
      const flicker = (el: SVGTextElement | null) => {
        if (!el) return;
        const ftl = gsap.timeline();
        ftl.to(el, { opacity: 0.4, duration: 0.05 })
           .to(el, { opacity: 0.1, duration: 0.03 })
           .to(el, { opacity: 0.8, duration: 0.08 })
           .to(el, { opacity: 0.2, duration: 0.04 })
           .to(el, { opacity: 1,   duration: 0.15 })
           .to(el, { opacity: 0.3, duration: 0.05 })
           .to(el, { opacity: 1,   duration: 0.2 });
        return ftl;
      };

      tl.add(flicker(textRef.current), 0.4)
        .add(flicker(secondaryTextRef.current), 0.6)
        // Subtle continuous hum/flicker after appearing
        .to([textRef.current, secondaryTextRef.current], {
          opacity: 0.92,
          duration: 0.1,
          repeat: -1,
          yoyo: true,
          ease: "none",
          repeatRefresh: true,
        });

      // ── Exit Logic ────────────────────────────────────────────────
      let animDone  = false;
      let pageDone  = false;
      let heroReady = false;
      let videoReady = false;

      const tryExit = () => {
        if (!animDone || !pageDone || !heroReady || !videoReady || !containerRef.current) return;

        // Final exit sequence
        gsap.to(containerRef.current, {
          autoAlpha: 0,
          duration: 0.8,
          ease: 'power4.inOut',
          onStart: () => {
            window.dispatchEvent(new CustomEvent(PRELOADER_DONE_EVENT));
          },
          onComplete: () => {
            sessionStorage.setItem('mg_preloader_done', '1');
            if (rootRef.current) {
              rootRef.current.style.display = 'none';
            }
          }
        });
      };

      // Ensure minimum visibility time
      gsap.delayedCall(2.2, () => { animDone = true; tryExit(); });

      pageDone = true;
      tryExit();

      const heroReadyHandler = () => { heroReady = true; tryExit(); };
      window.addEventListener(HERO_READY_EVENT, heroReadyHandler, { once: true });
      gsap.delayedCall(2.5, () => { heroReady = true; tryExit(); });

      const videoReadyHandler = () => { videoReady = true; tryExit(); };
      window.addEventListener(HERO_VIDEO_READY_EVENT, videoReadyHandler, { once: true });
      gsap.delayedCall(4, () => { videoReady = true; tryExit(); });

      // Clean up event listeners on unmount
      return () => {
        window.removeEventListener(HERO_READY_EVENT, heroReadyHandler);
        window.removeEventListener(HERO_VIDEO_READY_EVENT, videoReadyHandler);
      };

      }, rootRef); // end gsap.context

      cleanup = () => ctx.revert();
    })();

    return () => { 
      mounted = false; 
      cleanup(); 
    };
  }, [skip]);

  if (skip) return null;

  return (
    <div
      ref={rootRef}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: '#000000',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        pointerEvents: 'all'
      }}
    >
      <div
        ref={containerRef}
        style={{
          width: '100%',
          maxWidth: '1200px',
          padding: '0 2rem',
          opacity: 0
        }}
      >
        <svg
          viewBox="0 0 800 200"
          xmlns="http://www.w3.org/2000/svg"
          style={{ width: '100%', height: 'auto', overflow: 'visible' }}
        >
          {/* Main "MOTION" text with blue stroke */}
          <text
            ref={textRef}
            x="50%"
            y="45%"
            textAnchor="middle"
            dominantBaseline="middle"
            style={{
              fontSize: '110px',
              fontWeight: 900,
              fontFamily: 'system-ui, -apple-system, sans-serif',
              fill: 'transparent',
              stroke: '#0894ff',
              strokeWidth: '0.8',
              letterSpacing: '0.1em',
              textTransform: 'uppercase'
            }}
          >
            MOTION
          </text>

          {/* "GRACE" secondary text, slightly smaller */}
          <text
            ref={secondaryTextRef}
            x="50%"
            y="85%"
            textAnchor="middle"
            dominantBaseline="middle"
            style={{
              fontSize: '40px',
              fontWeight: 400,
              fontFamily: 'system-ui, -apple-system, sans-serif',
              fill: 'transparent',
              stroke: 'rgba(255,255,255,0.2)',
              strokeWidth: '0.5',
              letterSpacing: '0.8em',
              textTransform: 'uppercase'
            }}
          >
            GRACE
          </text>

          {/* Ambient glow behind text */}
          <defs>
            <radialGradient id="preloaderGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(8, 148, 255, 0.1)" />
              <stop offset="100%" stopColor="transparent" />
            </radialGradient>
          </defs>
          <rect x="0" y="0" width="800" height="200" fill="url(#preloaderGlow)" />
        </svg>
      </div>
    </div>
  );
}
